import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("raw_material_data_v2.csv")

# Select features for clustering
features = df[["Total_Cost", "Delivery_Time_Days", "Defect_Rate_%"]]

# Standardize features
scaler = StandardScaler()
scaled_features = scaler.fit_transform(features)

# Determine optimal number of clusters using Elbow Method
inertia = []
for k in range(1, 11):
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(scaled_features)
    inertia.append(kmeans.inertia_)

# Plot elbow curve
plt.figure(figsize=(8, 4))
plt.plot(range(1, 11), inertia, marker='o')
plt.title('Elbow Method For Optimal K')
plt.xlabel('Number of Clusters')
plt.ylabel('Inertia')
plt.grid(True)
plt.show()

# Fit KMeans with chosen number of clusters (e.g., 3)
kmeans = KMeans(n_clusters=3, random_state=42)
df['Cluster'] = kmeans.fit_predict(scaled_features)

# Visualize clusters
sns.pairplot(df, vars=["Total_Cost", "Delivery_Time_Days", "Defect_Rate_%"], hue="Cluster", palette="Set2")
plt.suptitle("K-Means Clustering Results", y=1.02)
plt.show()

# Print cluster centroids in original scale
centroids = scaler.inverse_transform(kmeans.cluster_centers_)
centroids_df = pd.DataFrame(centroids, columns=["Total_Cost", "Delivery_Time_Days", "Defect_Rate_%"])
print("\nCluster Centers (Original Scale):")
print(centroids_df.round(2))
