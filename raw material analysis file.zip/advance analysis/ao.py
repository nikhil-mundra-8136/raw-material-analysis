import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import IsolationForest

# Load dataset
df = pd.read_csv("raw_material_data_v2.csv")

# Select features for anomaly detection
features = df[["Price_per_Unit", "Delivery_Time_Days"]]

# Fit Isolation Forest
iso_forest = IsolationForest(n_estimators=100, contamination=0.05, random_state=42)
df['Anomaly'] = iso_forest.fit_predict(features)

# -1 indicates anomaly
anomalies = df[df['Anomaly'] == -1]
normal = df[df['Anomaly'] != -1]

# Visualize results
plt.figure(figsize=(10, 6))
sns.scatterplot(data=normal, x="Price_per_Unit", y="Delivery_Time_Days", label="Normal", color="blue")
sns.scatterplot(data=anomalies, x="Price_per_Unit", y="Delivery_Time_Days", label="Anomaly", color="red")
plt.title("Anomaly Detection - Price vs Delivery Time")
plt.xlabel("Price per Unit")
plt.ylabel("Delivery Time (Days)")
plt.legend()
plt.grid(True)
plt.show()

# Output anomalies
print("\nDetected Anomalies:")
print(anomalies[["Supplier", "Material", "Price_per_Unit", "Delivery_Time_Days", "Total_Cost"]].reset_index(drop=True))
